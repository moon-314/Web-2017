id=prompt('아이디 입력');
if(id=='123') {
    password=prompt('비밀번호 입력');
    if(password==='123') {
        location.href="로그인.html" 
    }
    else {
        location.href="error.html" 
    }
}
else {
    location.href="error.html" 
}
